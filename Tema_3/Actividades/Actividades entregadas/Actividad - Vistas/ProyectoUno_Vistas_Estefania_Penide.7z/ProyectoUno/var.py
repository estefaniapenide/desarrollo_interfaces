global ui
global dlgsalir
'''global bgSexo'''
global cbPago
global dlgCalendario
global pay



