global ui
global dlgsalir