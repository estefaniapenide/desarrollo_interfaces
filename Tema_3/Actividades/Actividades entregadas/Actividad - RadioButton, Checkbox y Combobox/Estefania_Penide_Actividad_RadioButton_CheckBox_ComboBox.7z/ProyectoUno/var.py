global ui
global dlgsalir
'''global bgSexo'''
global cbPago
