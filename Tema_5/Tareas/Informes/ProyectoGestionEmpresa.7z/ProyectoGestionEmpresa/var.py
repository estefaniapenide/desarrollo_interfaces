global ui
global dlgsalir
'''global bgSexo'''
global cbPago
global dlgCalendario
global pay
global pay2
global filedb
global filedlgabrir
global copia
global formaEnvio
global rep
global registrosPagInforme


