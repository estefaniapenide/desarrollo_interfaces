global ui
global dlgsalir
'''global bgSexo'''
global cbPago
global dlgCalendario
global pay
global pay2
global filebd



